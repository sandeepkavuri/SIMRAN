﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Globalization;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class SignIn : System.Web.UI.Page
{

    protected void BtnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString);
            SqlDataReader reader;
            conn.Open();
            string Query = "SELECT * FROM [Users] WHERE Email = @Email AND Password = @Password";
            SqlCommand cmd = new SqlCommand(Query, conn);
            cmd.Parameters.AddWithValue("@Email", txt_email.Value);
            cmd.Parameters.AddWithValue("@Password", txt_password.Value);
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                this.Session["LOGIN"] = 1;
                this.Session["LOGIN_ID"] = reader["Id"];
                Response.Redirect("Dashboard.aspx");
            } else {
                throw new Exception("Invalid Email or Passwword");
            }
            reader.Close();
            cmd.Dispose();
            conn.Close();
        }
        catch (SqlException ex)
        {
            HtmlControl control = FindControl("error_msg") as HtmlControl;
            control.Attributes["class"] = "alert alert-danger";
            error_msg.InnerHtml = "Sql Error : " + ex.Message.ToString();
        }
        catch (Exception ex)
        {
            HtmlControl control = FindControl("error_msg") as HtmlControl;
            control.Attributes["class"] = "alert alert-danger";
            error_msg.InnerHtml = ex.Message.ToString();
        }
    }
}